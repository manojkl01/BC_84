package org.thbs;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("service1")
public class ServiceA implements Service{


    @Override
    public String getInfo() {
        return "ServiceA's info";
    }

}
