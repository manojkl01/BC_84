package org.thbs;

public interface Service {
    String getInfo();
}
