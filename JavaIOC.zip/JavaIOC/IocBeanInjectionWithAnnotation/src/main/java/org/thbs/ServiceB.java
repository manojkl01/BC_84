package org.thbs;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("service2")
public class ServiceB implements Service{

    @Override
    public String getInfo() {
        return "ServiceB's info";
    }
}
