package org.thbs;

public interface Client {
    void request();
}
