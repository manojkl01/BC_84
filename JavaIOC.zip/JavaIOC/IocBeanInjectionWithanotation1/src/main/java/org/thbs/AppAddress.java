package org.thbs;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import lombok.*;
@Component("address")


@Getter
@ToString

public class AppAddress {
    private String doorno;
    private String street;
    private String city;
    private String state;
    private int pin;

    @Autowired
    public AppAddress() {
    }

    public AppAddress(String doorno, String street, String city, String state, int pin) {
        this.doorno = doorno;
        this.street = street;
        this.city = city;
        this.state = state;
        this.pin = pin;
    }


   public void setDoorno(String doorno) {
        this.doorno = doorno;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setState(String state) {
        this.state = state;
    }

    public void setPin(int pin) {
        this.pin = pin;
    }
}
