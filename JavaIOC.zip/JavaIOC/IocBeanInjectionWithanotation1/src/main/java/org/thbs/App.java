package org.thbs;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
        context.scan("org.thbs");
        context.refresh();

        Customer customer=(Customer)context.getBean("customer");
        customer.setCustId(1001);
        customer.setCusName("Manoj");

        AppAddress address=(AppAddress)customer.getAddress();
        address.setDoorno("31");
        address.setStreet("Nandini Layout");
        address.setCity("Bengaluru");
        address.setState("Karnataka");
        address.setPin(560096);

        System.out.println(customer);
    }
}
