package org.thbs;

import lombok.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component("customer")


@ToString
@Getter
public class Customer {
    private int custId;
    private String cusName;
    private AppAddress address;

    @Autowired
    public Customer(AppAddress address) {
        this.address = address;
    }

    public Customer(String cusName) {
        this.cusName = cusName;
    }
    public void setCustId(int custId) {
        this.custId = custId;
    }

    public void setCusName(String cusName) {
        this.cusName = cusName;
    }

    public void setAddress(AppAddress address) {
        this.address = address;
    }
}
