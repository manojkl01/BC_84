package org.thbs;

import org.springframework.stereotype.Component;

public class ServiceB implements Service{

    @Override
    public String getInfo() {
        return "ServiceB's info";
    }
}
