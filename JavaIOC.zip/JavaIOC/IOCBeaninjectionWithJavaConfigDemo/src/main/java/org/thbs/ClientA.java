package org.thbs;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

public class ClientA implements Client{
    Service service;

    public ClientA(Service service1) {
        this.service = service1;
    }

    @Override
    public void request() {
        System.out.println("Request a response");
        System.out.println("Response"+service.getInfo());
    }
}
