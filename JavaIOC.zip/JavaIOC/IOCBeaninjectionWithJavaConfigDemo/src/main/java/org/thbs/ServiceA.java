package org.thbs;

import org.springframework.stereotype.Component;

public class ServiceA implements Service{

    @Override
    public String getInfo() {
        return "ServiceA's info";
    }

}
