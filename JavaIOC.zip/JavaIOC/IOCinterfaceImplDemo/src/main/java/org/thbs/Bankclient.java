package org.thbs;

import lombok.*;

public class Bankclient {
    Bank bank;

    public Bankclient(Bank bank){
        this.bank=bank;
    }

    public Bank getBank() {
        return bank;
    }

    public void setBank(Bank bank) {
        this.bank = bank;
    }
    public double getBalance(long accId) {
        System.out.println("Balance is:");
        return bank.getBalance(accId);
    }
    public double withdraw(long accId, double amount) {
        System.out.println("Amount withdrawn is:");
        return bank.withdraw(accId, amount);
    }
    public double deposit(long accId, double amount) {
        System.out.println("Amount deposited: ");
        return bank.deposit(accId, amount);
    }
}
