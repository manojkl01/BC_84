package org.thbs;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context=new ClassPathXmlApplicationContext("file:src/main/java/beans.xml");
        Bankclient b1=(Bankclient) context.getBean("client1");
        System.out.println(b1.deposit(123456l, 4000.0));
        System.out.println();
        System.out.println(b1.withdraw(123456l, 1000.0));
        System.out.println();
        System.out.println(b1.getBalance(123456l));

        Bankclient b2=(Bankclient) context.getBean("client2");
        System.out.println(b2.deposit(12345l, 400.0));
        System.out.println();
        System.out.println(b2.withdraw(12345l, 100.0));
        System.out.println();
        System.out.println(b2.getBalance(12345l));

        ((ClassPathXmlApplicationContext) context).close();
    }
}
