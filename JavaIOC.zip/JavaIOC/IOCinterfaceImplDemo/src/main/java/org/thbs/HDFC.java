package org.thbs;

public class HDFC implements Bank{

    @Override
    public double getBalance(long accId) {
        System.out.println("HDFC Balance:");
        return Math.random()*1000;
    }

    @Override
    public double withdraw(long accId, double amount) {
        System.out.println("HDFC withdrawl");
        return Math.random()*100;
    }

    @Override
    public double deposit(long accId, double amount) {
        System.out.println("HDFC deposit");
        return Math.random()*2000;
    }
}
