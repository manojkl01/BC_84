package org.thbs;

public interface Bank {
    double getBalance(long accId);
    double withdraw(long accId,double amount);
    double deposit(long accId, double amount);
}
