package com.thbs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Oct19SpringBootRestProject5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
