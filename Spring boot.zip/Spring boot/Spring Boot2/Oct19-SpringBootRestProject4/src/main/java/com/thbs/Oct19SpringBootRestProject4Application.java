package com.thbs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Oct19SpringBootRestProject4Application {

	public static void main(String[] args) {
		SpringApplication.run(Oct19SpringBootRestProject4Application.class, args);
	}

}
