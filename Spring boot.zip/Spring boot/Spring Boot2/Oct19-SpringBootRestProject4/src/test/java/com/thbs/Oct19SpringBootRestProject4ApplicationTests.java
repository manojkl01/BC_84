package com.thbs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Oct19SpringBootRestProject4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
