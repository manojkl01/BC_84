package com.thbs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Oct19SpringBootRestProject6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
