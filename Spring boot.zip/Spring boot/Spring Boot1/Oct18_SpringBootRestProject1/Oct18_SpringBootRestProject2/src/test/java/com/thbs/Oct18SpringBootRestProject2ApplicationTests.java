package com.thbs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Oct18SpringBootRestProject2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
