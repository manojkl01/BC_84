package com.thbs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Oct18SpringBootRestProject2Application {

	public static void main(String[] args) {
		SpringApplication.run(Oct18SpringBootRestProject2Application.class, args);
	}

}
