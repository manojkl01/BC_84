package torryharris.b84.SpringJdbcdemo1;

public class BookService {
	
	public String insertrows(int empId, String empName, int salaray)
	{
	// create the emoloyee object 
		// call the insert of the empoloyeeDao1
		
		// insert(employee)
		
		return "row inserted successfully";
	}

}
