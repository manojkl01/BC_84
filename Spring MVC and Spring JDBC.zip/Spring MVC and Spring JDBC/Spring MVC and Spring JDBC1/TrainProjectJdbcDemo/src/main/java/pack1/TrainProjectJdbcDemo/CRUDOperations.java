package pack1.TrainProjectJdbcDemo;

public interface CRUDOperations {
	
	public void insert(Train book);
	

}

