package pack1.SpringJdbcDemo2;

public interface EmployeeCRUDOperations {
	
	public void insert(Employee employee);
}
