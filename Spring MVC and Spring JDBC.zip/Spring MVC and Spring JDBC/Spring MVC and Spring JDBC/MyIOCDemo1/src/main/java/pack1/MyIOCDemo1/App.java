package pack1.MyIOCDemo1;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       Application
    }
}
